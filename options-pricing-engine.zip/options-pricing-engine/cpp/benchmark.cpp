#include <iostream>
#include <chrono>
#include "black_scholes.hpp"
#include "binomial_tree.hpp"
#include "monte_carlo.hpp"

int main() {
    OptionParams p{100, 100, 1.0, 0.05, 0.2};

    std::cout << "======================================================================\n";
    std::cout << "C++ RUNTIME BENCHMARK\n";
    std::cout << "======================================================================\n";

    // Black-Scholes: 10,000 calls with varying spot price, so the compiler
    // can't constant-fold the whole loop away (which it will do if every
    // call has identical inputs).
    {
        auto t0 = std::chrono::high_resolution_clock::now();
        volatile double sink = 0.0;
        for (int i = 0; i < 10000; ++i) {
            OptionParams pi = p;
            pi.S = 50.0 + static_cast<double>(i) * 0.01;  // vary input each iteration
            sink = bs_call_price(pi);
        }
        auto t1 = std::chrono::high_resolution_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
        std::cout << "Black-Scholes:  10,000 calls in " << ms << " ms  ("
                  << (ms * 1000.0 / 10000.0) << " us/call)\n";
    }

    // Binomial tree at various step counts
    for (int n_steps : {100, 500, 1000}) {
        auto t0 = std::chrono::high_resolution_clock::now();
        binomial_price(p, true, n_steps, false);
        auto t1 = std::chrono::high_resolution_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
        std::cout << "Binomial tree (N=" << n_steps << "):  " << ms << " ms\n";
    }

    // Monte Carlo at various path counts
    for (long n_paths : {10000L, 100000L, 1000000L}) {
        auto t0 = std::chrono::high_resolution_clock::now();
        monte_carlo_price(p, true, n_paths, true);
        auto t1 = std::chrono::high_resolution_clock::now();
        double ms = std::chrono::duration<double, std::milli>(t1 - t0).count();
        std::cout << "Monte Carlo (paths=" << n_paths << "):  " << ms << " ms\n";
    }

    return 0;
}
