#include <iostream>
#include "black_scholes.hpp"

int main() {
    OptionParams p{100, 100, 1.0, 0.05, 0.2};

    double call = bs_call_price(p);
    double put = bs_put_price(p);

    std::cout << "Call price: " << call << "\n";
    std::cout << "Put price:  " << put << "\n";

    // Put-call parity check
    double lhs = call - put;
    double rhs = p.S * std::exp(-p.q * p.T) - p.K * std::exp(-p.r * p.T);
    std::cout << "Put-call parity holds: "
              << (std::abs(lhs - rhs) < 1e-8 ? "true" : "false") << "\n";

    return 0;
}
