#pragma once
#include <vector>
#include <cmath>
#include <random>
#include <algorithm>
#include <numeric>
#include "black_scholes.hpp"

// Monte Carlo pricer with antithetic variates. Mirrors the core of
// python/monte_carlo.py; control variates are implemented in Python only
// since the runtime benefit of C++ is already demonstrated by antithetic
// + raw path simulation, which is where most of the compute time goes.

struct MCResult {
    double price;
    double stderr_;
};

inline MCResult monte_carlo_price(
    const OptionParams& p,
    bool is_call,
    long n_paths = 100000,
    bool antithetic = true,
    unsigned int seed = 42
) {
    std::mt19937_64 rng(seed);
    std::normal_distribution<double> normal(0.0, 1.0);

    double drift = (p.r - p.q - 0.5 * p.sigma * p.sigma) * p.T;
    double diffusion_coef = p.sigma * std::sqrt(p.T);
    double disc = std::exp(-p.r * p.T);

    std::vector<double> discounted_payoffs;
    discounted_payoffs.reserve(n_paths);

    long n_draws = antithetic ? n_paths / 2 : n_paths;

    for (long i = 0; i < n_draws; ++i) {
        double z = normal(rng);

        double s_t1 = p.S * std::exp(drift + diffusion_coef * z);
        double payoff1 = is_call ? std::max(s_t1 - p.K, 0.0) : std::max(p.K - s_t1, 0.0);
        discounted_payoffs.push_back(disc * payoff1);

        if (antithetic) {
            double s_t2 = p.S * std::exp(drift - diffusion_coef * z);
            double payoff2 = is_call ? std::max(s_t2 - p.K, 0.0) : std::max(p.K - s_t2, 0.0);
            discounted_payoffs.push_back(disc * payoff2);
        }
    }

    double n = static_cast<double>(discounted_payoffs.size());
    double mean = std::accumulate(discounted_payoffs.begin(), discounted_payoffs.end(), 0.0) / n;

    double sq_sum = 0.0;
    for (double v : discounted_payoffs) {
        sq_sum += (v - mean) * (v - mean);
    }
    double stddev = std::sqrt(sq_sum / (n - 1));
    double stderr_val = stddev / std::sqrt(n);

    return {mean, stderr_val};
}
