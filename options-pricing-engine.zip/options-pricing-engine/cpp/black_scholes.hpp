#pragma once
#include <cmath>
#include <stdexcept>

// Black-Scholes closed-form option pricing.
// Mirrors python/black_scholes.py so results can be validated 1:1.

struct OptionParams {
    double S;      // spot price
    double K;      // strike
    double T;      // time to expiry (years)
    double r;      // risk-free rate
    double sigma;  // volatility
    double q = 0.0; // continuous dividend yield
};

// Standard normal CDF via erf (no external dependency needed).
inline double norm_cdf(double x) {
    return 0.5 * std::erfc(-x / std::sqrt(2.0));
}

inline double norm_pdf(double x) {
    static const double INV_SQRT_2PI = 0.3989422804014327;
    return INV_SQRT_2PI * std::exp(-0.5 * x * x);
}

struct D1D2 {
    double d1;
    double d2;
};

inline D1D2 compute_d1_d2(const OptionParams& p) {
    if (p.T <= 0 || p.sigma <= 0) {
        throw std::invalid_argument("T and sigma must be strictly positive");
    }
    double d1 = (std::log(p.S / p.K) + (p.r - p.q + 0.5 * p.sigma * p.sigma) * p.T)
                / (p.sigma * std::sqrt(p.T));
    double d2 = d1 - p.sigma * std::sqrt(p.T);
    return {d1, d2};
}

inline double bs_call_price(const OptionParams& p) {
    auto [d1, d2] = compute_d1_d2(p);
    return p.S * std::exp(-p.q * p.T) * norm_cdf(d1)
         - p.K * std::exp(-p.r * p.T) * norm_cdf(d2);
}

inline double bs_put_price(const OptionParams& p) {
    auto [d1, d2] = compute_d1_d2(p);
    return p.K * std::exp(-p.r * p.T) * norm_cdf(-d2)
         - p.S * std::exp(-p.q * p.T) * norm_cdf(-d1);
}

inline double bs_price(const OptionParams& p, bool is_call) {
    return is_call ? bs_call_price(p) : bs_put_price(p);
}
