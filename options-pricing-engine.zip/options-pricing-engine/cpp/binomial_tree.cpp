#include <iostream>
#include "black_scholes.hpp"
#include "binomial_tree.hpp"

int main() {
    OptionParams p{100, 100, 1.0, 0.05, 0.2};

    double bs_call = bs_call_price(p);
    double bs_put = bs_put_price(p);

    double euro_call = binomial_price(p, true, 500, false);
    double euro_put = binomial_price(p, false, 500, false);
    double amer_call = binomial_price(p, true, 500, true);
    double amer_put = binomial_price(p, false, 500, true);

    std::cout << "Convergence check vs Black-Scholes (European, N=500):\n";
    std::cout << "  Call: BS=" << bs_call << "  Binomial=" << euro_call
              << "  diff=" << std::abs(bs_call - euro_call) << "\n";
    std::cout << "  Put:  BS=" << bs_put << "  Binomial=" << euro_put
              << "  diff=" << std::abs(bs_put - euro_put) << "\n";

    std::cout << "\nAmerican vs European (early exercise premium):\n";
    std::cout << "  Call: American=" << amer_call << "  European=" << euro_call
              << "  premium=" << (amer_call - euro_call) << "\n";
    std::cout << "  Put:  American=" << amer_put << "  European=" << euro_put
              << "  premium=" << (amer_put - euro_put) << "\n";

    return 0;
}
